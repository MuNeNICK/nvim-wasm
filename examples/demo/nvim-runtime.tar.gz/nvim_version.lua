return {
  {"major", 0},
  {"minor", 12},
  {"patch", 0},
  {"prerelease", "-dev" ~= ""},
  {"api_level", 14},
  {"api_compatible", 0},
  {"api_prerelease", true},
}
